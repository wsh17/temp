# Get-WmiObject -Class win32_operatingsystem -Property LastBootUpTime > output.txt
$os = Get-WmiObject win32_operatingsystem
$uptime = (Get-Date) - $os.ConvertToDateTime($os.LastBootUpTime)
# Write-Output ("Uptime: " + $uptime.Days + " Days " + $uptime.Hours + " Hours " + $uptime.Minutes + " Minutes") > output.txt
Write-Output ("name=Custom Metrics|Hardware Resources|Uptime|NumberOfDays, value=" + $uptime.Days) > output.txt
