#!/bin/bash

#Start Loop to pull data.
while [ 1 ]; do

#!/bin/bash

# Get the system boot time in seconds since epoch
boot_time=$(date -d "$(who -b | awk '{print $3, $4}')" +%s)

# Get the current time in seconds since epoch
current_time=$(date +%s)

# Calculate the total time since boot in seconds
total_uptime=$((current_time - boot_time))

# Define the time periods in seconds
last_24_hours=$((24 * 60 * 60))
last_30_days=$((30 * 24 * 60 * 60))

# Calculate 24-hour uptime percentage
if [ $total_uptime -ge $last_24_hours ]; then
    uptime_24h_percentage=100
else
    uptime_24h_percentage=$(awk "BEGIN {print int(($total_uptime/$last_24_hours)*100)}")
fi

# Calculate 30-day uptime percentage
if [ $total_uptime -ge $last_30_days ]; then
    uptime_30d_percentage=100
else
    uptime_30d_percentage=$(awk "BEGIN {print int(($total_uptime/$last_30_days)*100)}")
fi

# Output the results

echo "name=Custom Metrics|Uptime|24hrs, value=$uptime_24h_percentage"
echo "name=Custom Metrics|Uptime|30Days, value=$uptime_30d_percentage"

sleep 300
done
